﻿using CRUD_DAL.Interface;
using CRUD_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD_BAL.Service
{
    public class UserVerifyService
    {
        private readonly IRepository<UserVerify> _UserVerify;

        public UserVerifyService(IRepository<UserVerify> perosn)
        {
            _UserVerify = perosn;
        }
        //Get Person Details By Person Id
        public IEnumerable<UserVerify> GetPersonByUserId(long UserId, int OTP)
        {
            //_UserVerify.GetById(UserId);
            return _UserVerify.GetAll().Where(x => x.MobileNumber == UserId && x.OTP==OTP).ToList();
        }
        //Add Person
        public async Task<UserVerify> AddPerson(UserVerify Person)
        {
            return await _UserVerify.Create(Person);
        }
        //Update Person Details
        public bool UpdatePerson(UserVerify person)
        {
            try
            {
                var DataList = _UserVerify.GetAll().ToList();
                foreach (var item in DataList)
                {
                    if (item.MobileNumber == person.MobileNumber && item.OTP == person.OTP)
                    {
                        item.Name = person.Name;
                        item.Email = person.Email;
                        _UserVerify.Update(item);
                    }
                }
                return true;
            }
            catch (Exception)
            {
                return true;
            }
        }
    }
}