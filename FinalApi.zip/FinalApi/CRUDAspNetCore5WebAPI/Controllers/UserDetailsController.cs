﻿using CRUD_BAL.Service;
using CRUD_DAL.Interface;
using CRUD_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUDAspNetCore5WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserDetailsController : ControllerBase
    {
        
        private readonly UserVerifyService _UserVerifyService;

        private readonly IRepository<UserVerify> _UserVerify;
        public UserDetailsController( IRepository<UserVerify> UserVerify, UserVerifyService UserVerifyService)
        {


            _UserVerifyService = UserVerifyService;
            _UserVerify = UserVerify;

        }
        
        
        //GET All Person by Name
        [HttpGet("GetUserMobileVerify")]
        public async Task<Object> GetUserMobileVerify(long MobileNumber)
        {
            int OTPNumber = 0;
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            OTPNumber = _rdm.Next(_min, _max);
            UserVerify obj = new UserVerify();
            obj.MobileNumber = MobileNumber;
            obj.OTP = OTPNumber;
            await _UserVerifyService.AddPerson(obj);

            var json = JsonConvert.SerializeObject(OTPNumber, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }
        //GET All Person by Name
        [HttpGet("FirstTimeValidateUser")]
        public Object FirstTimeValidateUser(string Name, string email, long MobileNumber, int OTP)
        {
            string response = "";
            var data=_UserVerifyService.GetPersonByUserId(MobileNumber, OTP);
            if (data.Count() != 0)
            {
                UserVerify obj = new UserVerify();
                obj.Name = Name;
                obj.Email = email;
                obj.MobileNumber = MobileNumber;
                obj.OTP = OTP;
                _UserVerifyService.UpdatePerson(obj);
                response = "success";
            }
            else
            {
                response = "failed";
            }
            var json = JsonConvert.SerializeObject(response, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }
        //GET All Person by Name
        [HttpGet("NormalLoginValidateUser")]
        public Object NormalLoginValidateUser(long MobileNumber, int OTP)
        {
            string response = "";
            var data = _UserVerifyService.GetPersonByUserId(MobileNumber, OTP);
            if(data.Count()!=0)
            {
                response = "success";
            }
            else
            {
                response = "please sign-up";
            }

            var json = JsonConvert.SerializeObject(response, Formatting.Indented,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                }
            );
            return json;
        }


    }
    }