﻿using CRUD_DAL.Data;
using CRUD_DAL.Interface;
using CRUD_DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD_DAL.Repository
{
    public class RepositoryUserVerify : IRepository<UserVerify>
    {
        ApplicationDbContext _dbContext;
        public RepositoryUserVerify(ApplicationDbContext applicationDbContext)
        {
            _dbContext = applicationDbContext;
        }
        public UserVerify GetById(long Id)
        {
            return _dbContext.UserVerifys.Where(x => x.MobileNumber == Id).FirstOrDefault();
        }
        public async Task<UserVerify> Create(UserVerify _object)
        {
            var obj = await _dbContext.UserVerifys.AddAsync(_object);
            _dbContext.SaveChanges();
            return obj.Entity;
        }

        public void Update(UserVerify _object)
        {
            _dbContext.UserVerifys.Update(_object);
            _dbContext.SaveChanges();
        }


        public void Delete(UserVerify _object)
        {
            _dbContext.Remove(_object);
            _dbContext.SaveChanges();
        }

        public IEnumerable<UserVerify> GetAll()
        {
            try
            {
                //var data = _dbContext.UserVerifys.Where(x => x.IsDeleted == false).ToList();
                return _dbContext.UserVerifys.Where(x => x.IsDeleted == false).ToList();
            }
            catch (Exception ee)
            {
                throw ee;
            }
        }

    }
}
