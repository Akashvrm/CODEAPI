﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CRUD_DAL.Models
{
    [Table("UserVerifys", Schema = "dbo")]
    public class UserVerify
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Display(Name = "MobileNumber")]
        public long MobileNumber { get; set; }

        [Display(Name = "OTP")]
        public int OTP { get; set; }
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Email")]
        public string Email { get; set; }


        public bool IsDeleted { get; set; } = false;
    }
}
